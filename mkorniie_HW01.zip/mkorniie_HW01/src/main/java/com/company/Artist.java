package com.company;

import java.util.Random;

/**
 * Created by Maria on 18.02.18.
 */
public class Artist implements Paint{
    Factory f;
    Figure []arr;

    public Artist(int size) {
        f = new Factory();
        f.getFactoryInstance();
        arrInitialize(size);
    }

    public enum Shapes{
        CIRCLE,
        SQUARE,
        OVAL,
        RECTANGULAR
    }

    private void arrInitialize(int s){
        if (s == 0) {
            return;
        }
        arr = new Figure[s];
        int figType;

        for (int i = 0; i < s; i++)
        {
            figType = (int) Math.ceil((Math.random() * 4) - 1);
            if (figType == -1)
                figType = 0;
            arr[i] = f.getFigure(Shapes.values()[figType]);
            arr[i].setPoint((int) Math.ceil((Math.random() * 1000) - 500), (int) Math.ceil((Math.random() * 1000) - 500));
            arr[i].setWidth((int) Math.ceil(Math.random() * 500));
            if (figType > 1)
                arr[i].setHeight((int) Math.ceil(Math.random() * 500));
        }
    }

    public void paint(int s){
        int pos = 0;
        while((pos < arr.length) && (arr[pos] == null))
            pos++;
        if (pos == arr.length) {
            arrInitialize(s);
            pos = 0;
        }
        for(int i = pos; i < (pos + s); i++)
        {
            if (i >= arr.length) {
                arrInitialize(s - i);
                s -= i;
                i = 0;
            }
            arr[i].printFigure();
            arr[i] = null;
        }
    }

}

package com.company;

/**
 * Created by Maria on 10.02.18.
 */
public class Point {
    //immutable? I guess it is.
    private final int x;
    private final int y;

    public Point(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    public void getPoint()
    {
        System.out.println("(" + x + ";" + y + ")");
    }
}

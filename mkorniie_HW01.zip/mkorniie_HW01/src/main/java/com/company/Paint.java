package com.company;

/**
 * Created by Maria on 18.02.18.
 */
public interface Paint {
    public void paint(int s);
}

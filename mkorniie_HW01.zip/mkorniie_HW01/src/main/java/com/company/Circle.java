package com.company;

/**
 * Created by Maria on 10.02.18.
 */
public class Circle implements Figure{

    private int width;
    private Point p;

    public static class Builder{

        private int width = 0;
        private Point p;


        public Builder(int x, int y) {
            this.p = new Point(x, y);
        }

        public Builder width(int w) {
            width = w;
            return this;
        }

        public Circle buidl() {
            return new Circle(this);
        }
    }

    private Circle(Builder builder) {
        width = builder.width;
        p = builder.p;
    }

    public void setWidth(int w) {
        width = w;
    }

    public void setHeight(int h) {
        width = h;
    }

    public void setPoint(int x, int y) {
        p = new Point(x, y);
    }

    public void printPoint() {
        p.getPoint();
    }

    public int getWidth(){
        return width;
    }

    public void printFigure()
    {
        System.out.println("Circle:");
        System.out.print("  Centre coordinates: ");
        p.getPoint();
        System.out.println("  Width and height are: " + width + ", " + width);
    }
}

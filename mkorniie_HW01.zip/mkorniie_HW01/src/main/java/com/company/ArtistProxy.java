package com.company;

/**
 * Created by Maria on 18.02.18.
 */
public class ArtistProxy implements Paint {
    int arrSize;
    Artist a;

    public ArtistProxy(int size) {
        arrSize = size;
    }

    public void paint(int s) {
        if (a == null) {
            a = new Artist(arrSize);
        }
        a.paint(s);
    }
}

package com.company;

/**
 * Created by Maria on 11.02.18.
 */
public class Factory {
    private static volatile Factory instance;

    public static synchronized Factory getFactoryInstance() {
        if (instance == null) {
            instance = new Factory();
        }
        return instance;
    }

    public Figure getFigure(Artist.Shapes name) {
        Figure toReturn;
        if (name == Artist.Shapes.CIRCLE) {
            toReturn = new Circle.Builder(0,0)
                        .width(0)
                        .buidl();
        } else if (name == Artist.Shapes.OVAL) {
            toReturn = new Oval.Builder(0,0)
                    .width(0)
                    .height(0)
                    .buidl();
        } else if (name == Artist.Shapes.SQUARE) {
            toReturn = new Square.Builder(0,0)
                    .width(0)
                    .buidl();
        } else if (name == Artist.Shapes.RECTANGULAR) {
            toReturn = new Rectangular.Builder(0,0)
                    .width(0)
                    .height(0)
                    .buidl();
        } else {
            throw new IllegalArgumentException("Wrong name:" + name);
        }
        return toReturn;
    }
}
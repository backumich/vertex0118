package com.company;

/**
 * Created by Maria on 10.02.18.
 */
public interface Figure {

    public static class Builder{

    }

    public void setWidth(int w);
    public void setHeight(int h);
    public void setPoint(int x, int y);
    public void printFigure();
}

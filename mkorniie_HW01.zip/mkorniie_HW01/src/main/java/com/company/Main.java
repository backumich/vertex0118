package com.company;

public class Main {

    public static void main(String[] args) {
        ArtistProxy art0 = new ArtistProxy(2);
        art0.paint(1);
        art0.paint(1);
        art0.paint(1);
        art0.paint(33);
    }
}
